
require 'open-uri'
require 'nokogiri'
require 'pry'

module The_Keeper

end

require_relative "./book.rb"
require_relative "./Thebooklover/version"
require_relative "./scraper.rb"
require_relative "./cli.rb"
