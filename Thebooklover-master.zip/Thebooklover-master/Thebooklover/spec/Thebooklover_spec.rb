RSpec.describe Thebooklover do
  it "has a version number" do
    expect(Thebooklover::VERSION).not_to be nil
  end

  it "does something useful" do
    expect(false).to eq(true)
  end
end
